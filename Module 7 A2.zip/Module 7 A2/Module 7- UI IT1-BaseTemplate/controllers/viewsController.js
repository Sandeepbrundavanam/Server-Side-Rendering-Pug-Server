const axios = require('axios');
const courses = require('./../dev-data/data/courses.json');

exports.getLandingPAge = async (req, res) => {
  res.status(200).render('overview', {
    title: `Over View`
  
  });
};

// controller for viewing the loan list
exports.getLoanList = async (req, res) => {
  const query = await axios.get('http://localhost:3000/api/v1/loans')
  res.status(200).render('loanlists', {
    title: `Loan List`,
    "loans": query.data.data.loans
  });
};

exports.getCourse = async (req, res) => {
  res.status(200).render('courses', {
    title: `Get Course`
  });
};

exports.courseList = async (req, res) => {
  res.status(200).render('allCourses', {
    title: `List of courses`,
    "courses": courses
  });
};

exports.createNewCourse = async (req, res) => {
  res.status(200).render('newCourse', {
    title: `Create New Course`
  });
};

exports.getSignInForm = (req, res) => {
  res.status(200).render('newUser', {
    title: 'Sign in New User'
  });
};
exports.getLoginForm = (req, res) => {
  res.status(200).render('login', {
    title: 'Log into your account'
  });
};


